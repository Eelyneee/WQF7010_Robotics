#!/usr/bin/env python3
import rospy
from std_msgs.msg import Bool, String, Empty
from sensor_msgs.msg import Image
from cv_bridge import CvBridge, CvBridgeError

import cv2
import numpy as np
import mediapipe as mp
from keras.models import load_model
import time
import os
from datetime import datetime
import subprocess

class SmileDetectorRealTime:
    def __init__(self):
        rospy.init_node('smile_detector_node')

        self.face_detector = mp.solutions.face_detection.FaceDetection(model_selection=0, min_detection_confidence=0.5)
        self.bridge = CvBridge()
        self.detection_active = False
        self.model_loaded = False
        self.timeout_duration = 60  # seconds
        self.start_time = None

        # Publishers
        self.smile_pub = rospy.Publisher('/smile_detected', Bool, queue_size=1)
        self.tts_pub = rospy.Publisher('/say_text', String, queue_size=1)
        self.annotated_pub = rospy.Publisher('/annotated_image', Image, queue_size=1)
        self.camera_ready_pub = rospy.Publisher('/camera_ready', String, queue_size=1)
        self.image_view_ready_pub = rospy.Publisher('/image_view_ready', String, queue_size=1)
        self.face_detected_init_pub = rospy.Publisher('/face_detection_started', Empty, queue_size=1)

        # Subscribers
        rospy.Subscriber('/usb_cam/image_raw', Image, self.image_callback)
        rospy.Subscriber('/start_detection', String, self.start_detection_callback)

        # Load model
        model_path = os.path.join(os.path.dirname(__file__), '..', 'models', 'emotion_model.h5')
        try:
            self.model = load_model(model_path, compile=False)
            self.model_loaded = True
            rospy.loginfo("Smile model loaded.")
        except Exception as e:
            rospy.logerr(f"Error loading model: {e}")

        rospy.loginfo("Real-time SmileDetector running.")
        rospy.spin()
    
    def start_detection_callback(self, msg):
        if msg.data == "init_camera":
            # Launch usb_cam_node first
            try:
                self.usb_cam_proc = subprocess.Popen(['rosrun', 'usb_cam', 'usb_cam_node'])
                rospy.loginfo("usb_cam_node launched.")
                rospy.sleep(2)  # ✅ Give the camera time to start
                self.camera_ready_pub.publish("camera ready")
            except Exception as e:
                rospy.logerr(f"Failed to launch usb_cam_node: {e}")

            # Then launch image_view (after a short wait)
            try:
                self.image_view_proc = subprocess.Popen(
                    ['rosrun', 'image_view', 'image_view', 'image:=/annotated_image']
                )
                rospy.loginfo("Launched image_view for annotated_image.")
                rospy.sleep(1)  # ✅ Optional wait before publishing ready
                self.image_view_ready_pub.publish("image_view ready")
            except Exception as e:
                rospy.logerr(f"Failed to launch image_view: {e}")
                
        
        elif msg.data == "start":
            self.detection_active = True
            self.found_smile = False
            self.start_time = time.time()
            rospy.loginfo("Smile detection activated.")
            # self.tts_pub.publish("Smile please!")   

        elif msg.data == "stop":
            if hasattr(self, 'image_view_proc') and self.image_view_proc:
                self.image_view_proc.terminate()
                rospy.loginfo("Terminated image_view.")
                self.image_view_proc = None


    def image_callback(self, msg):
        if not self.detection_active or self.start_time is None:
            return   
      
        current_time = time.time()
        if current_time - self.start_time > self.timeout_duration:
            rospy.loginfo("Smile detection timed out. No smile detected.")
            self.smile_pub.publish(Bool(False))
            self.detection_active = False
            return

        # Preparing for detection
        try:
            frame = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
        except CvBridgeError as e:
            rospy.logerr(f"CV Bridge error: {e}")
            return

        output_frame = frame.copy()

        # If detection is still active, process for smile and annotate
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        results = self.face_detector.process(rgb)
        detected_smile = False

        if results.detections:
            all_smiling = False  # Start assuming not all are smiling
            all_labels = []

            
            for detection in results.detections:
                ih, iw, _ = frame.shape
                bbox = detection.location_data.relative_bounding_box
                x1 = int(bbox.xmin * iw)
                y1 = int(bbox.ymin * ih)
                x2 = x1 + int(bbox.width * iw)
                y2 = y1 + int(bbox.height * ih)

                x1, y1 = max(0, x1), max(0, y1)
                x2, y2 = min(iw, x2), min(ih, y2)

                face = frame[y1:y2, x1:x2]
                if face.size == 0:
                    continue

                # Wait 8 seconds after first face detection
                if not hasattr(self, 'face_detected_time'):
                    self.face_detected_time = time.time()
                    rospy.loginfo("Face detected. Waiting 8 seconds before checking smile.")
                    self.face_detected_init_pub.publish(Empty())
                    return  # Skip this frame to let time start

                if time.time() - self.face_detected_time < 8:
                    return  # Still within 8-second buffer

                gray_face = cv2.cvtColor(face, cv2.COLOR_BGR2GRAY)
                resized_face = cv2.resize(gray_face, (48, 48))
                normalized_face = resized_face.astype("float32") / 255.0
                input_data = normalized_face.reshape(1, 48, 48, 1)

                predictions = self.model.predict(input_data)
                # filtered = predictions[0][[3, 6]]  # Happy and Neutral
                # label = ['Smiling', 'Not Smiling'][np.argmax(filtered)]
                happy_prob = predictions[0][3]
                neutral_prob = predictions[0][6]
                
                if happy_prob > neutral_prob and happy_prob > 0.5: # A threshold can help avoid weak detections
                     label = 'Smiling'
                else:
                     label = 'Not Smiling'


                all_labels.append(label)

                # Draw bounding box + label
                color = (0, 255, 0) if label == "Smiling" else (0, 0, 255)
                cv2.rectangle(output_frame, (x1, y1), (x2, y2), color, 2)
                cv2.putText(output_frame, label, (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.8, color, 2)
        
               
            if all(label == "Smiling" for label in all_labels) and all_labels:
                detected_smile = True

        # Publish annotated image
        try:
            self.annotated_pub.publish(self.bridge.cv2_to_imgmsg(output_frame, encoding='bgr8'))
        except CvBridgeError as e:
            rospy.logerr(f"Error publishing annotated image: {e}")

        if detected_smile:
            self.handle_smile_event(detected_smile)
        else:
            # Say_please.py
            self.smile_pub.publish(False)


    def handle_smile_event(self, detected_smile):
        rospy.loginfo("Smile detected! Starting countdown.")

        # Publish the action
        self.smile_pub.publish(Bool(detected_smile))
        # self.tts_pub.publish("Photo taken!")
        self.detection_active  = False
        rospy.loginfo("Published!")

        # Close the view window
        rospy.sleep(15)
        subprocess.call(["pkill", "-f", "image_view"])
        subprocess.call(["pkill", "-f", "usb_cam_node"])
        self.image_view_proc = None # Clear process handles
        self.usb_cam_proc = None

if __name__ == '__main__':
    try:
        SmileDetectorRealTime()
    except rospy.ROSInterruptException:
        pass
