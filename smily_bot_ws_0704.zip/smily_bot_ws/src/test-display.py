import cv2
import numpy as np
import os

# Use the path to the photo your ROS node is trying to display
photo_path = "/home/mustar/smily_bot_ws/tmp/smile_photos/photo_20250704_110509.jpg"

image = None
if os.path.exists(photo_path):
    image = cv2.imread(photo_path)
    if image is None:
        print(f"Error: Could not read image from {photo_path}. File might be corrupted.")
        # Create a dummy image if the actual photo cannot be read
        image = np.zeros((480, 640, 3), dtype=np.uint8) # Black image
        cv2.putText(image, "Failed to load image", (50, 240), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 2)
else:
    print(f"Warning: Test photo not found at: {photo_path}")
    print("Creating a dummy black image for testing.")
    # Create a dummy image if the actual photo doesn't exist
    image = np.zeros((480, 640, 3), dtype=np.uint8) # Black image
    cv2.putText(image, "Dummy Image - No Photo Found", (50, 240), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)

if image is not None:
    print(f"Attempting to display image of shape: {image.shape}")
    cv2.imshow("Test OpenCV Display", image)
    print("Image display window should be open now. Press any key to close.")
    # Wait indefinitely until a key is pressed. This will keep the window open.
    cv2.waitKey(0) 
    cv2.destroyAllWindows()
    print("Window closed. Exiting.")
else:
    print("No image to display. Exiting.")